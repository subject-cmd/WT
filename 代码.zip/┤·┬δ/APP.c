1）用户注册相关程序：
String xingming=editText1.getText().toString();
String yonghuming=editText2.getText().toString();
String mima=editText3.getText().toString();

2）用户登录部分程序如下：
     if(jl==0){
Toast.makeText(Denglu.this，"该用户不存在，请重新注册"，Toast.LENGTH_LONG).show();
            }else{   
cursor.moveToFirst();//调用moveToFirst()获取cursor中的数据
               mm =cursor.getString(3);
               if(mm.equals(mima))
{  Intent intent=new Intent(this，Zhucaidan.class);//页面跳转[55]
               startActivity(intent);
                     }else{
           Toast.makeText(Denglu.this，"密码错误"，Toast.LENGTH_LONG).show();  }}
3）蓝牙开启序如下：
final BluetoothManager mblemanager = (BluetoothManager) getSystemService(Contex	  t.BLUETOOTH_SERVICE);   // 获取BluetoothManager
mbleadapter = mblemanager.getAdapter();//通过BluetoothManager获取getAdapter()
    public void bleScan(UUID[] specUUID) {
        if (!mbleadapter.isEnabled()) {
            mbleadapter.enable();//后台开启蓝牙
        } else {
        mbleadapter.startLeScan(specUUID， mLeScanCallback);//扫描蓝牙
        } }
