if((tp_dev.sta)&(1<<t))
{
if(tp_dev.x[t]<lcddev.width&&tp_dev.y[t]<lcddev.height)
{
if(lastpos[t][0]==0XFFFF)
{
lastpos[t][0] = tp_dev.x[t];
lastpos[t][1] = tp_dev.y[t];
}
/*
if(tp_dev.y[t]>92)
{
  lcd_draw_bline(lastpos[t][0],lastpos[t][1],tp_dev.x[t],tp_dev.y[t],2,POINT_COLOR_TBL[t]);//»Ïß
}
*/
lastpos[t][0]=tp_dev.x[t];
lastpos[t][1]=tp_dev.y[t];
if((190<tp_dev.x[t])&&(tp_dev.x[t]<250)&&(410<tp_dev.y[t])&&(tp_dev.y[t]<450))
{
SZ();
}
if((100<tp_dev.x[t])&&(tp_dev.x[t]<160)&&(340<tp_dev.y[t])&&(tp_dev.y[t]<380))
{
Load_Drow_Dialog1();//·¢ËÍ²âÁ¿ÑªÌÇÃüÁî
}
if((350<tp_dev.x[t])&&(tp_dev.x[t]<390)&&(340<tp_dev.y[t])&&(tp_dev.y[t]<380))
{
LCD_Fill(184,340,265,380,WHITE); ////Çå¿ÕÑªÌÇÏÔÊ¾ 
} 
if((100<tp_dev.x[t])&&(tp_dev.x[t]<160)&&(200<tp_dev.y[t])&&(tp_dev.y[t]<240))
{
TIM_Cmd(TIM3,ENABLE); //Ê¹ÄÜ¶¨Ê±Æ÷3        ·¢ËÍ²âÁ¿ÎÂ¶ÈÃüÁî
} 
if((350<tp_dev.x[t])&&(tp_dev.x[t]<390)&&(200<tp_dev.y[t])&&(tp_dev.y[t]<240))
{
TIM_Cmd(TIM3,DISABLE); //²»Ê¹ÄÜ¶¨Ê±Æ÷3      ¹Ø±Õ²âÁ¿ÎÂ¶ÈÃüÁî
  LCD_Fill(184,200,265,240,WHITE);        ////Çå¿ÕÎÂ¶ÈÊýÖµ
LCD_Fill(300,210,330,230,WHITE);        ////Çå¿ÕÏÔÊ¾µÄÂÌ/ºì·½¿é
LCD_DrawRectangle(300,210,330,230);     ////ÏÔÊ¾·½¿ò
} 
if((100<tp_dev.x[t])&&(tp_dev.x[t]<160)&&(130<tp_dev.y[t])&&(tp_dev.y[t]<170))
{
USART_ITConfig(USART6, USART_IT_RXNE, ENABLE); //  ·¢ËÍ²âÁ¿ÐÄµçÃüÁî
} 
if((350<tp_dev.x[t])&&(tp_dev.x[t]<390)&&(130<tp_dev.y[t])&&(tp_dev.y[t]<170))
{
USART_ITConfig(USART6, USART_IT_RXNE, DISABLE); //   ¹Ø±Õ²âÁ¿ÐÄµçÃüÁî
  LCD_Fill(184,130,265,170,WHITE);     ////Çå¿ÕÐÄµçÊýÖµ
LCD_Fill(300,140,330,160,WHITE);     ////Çå¿ÕÏÔÊ¾µÄÂÌ/ºì·½¿é
LCD_Fill(0,0,480,120,WHITE);         ////Çå¿ÕÉÏ·½ÏÔÊ¾µÄÐÄµç²¨ÐÎ
LCD_DrawRectangle(300,140,330,160);  ////ÏÔÊ¾·½¿ò
} 
if((100<tp_dev.x[t])&&(tp_dev.x[t]<160)&&(270<tp_dev.y[t])&&(tp_dev.y[t]<310))
{
TIM_Cmd(TIM5,ENABLE); //Ê¹ÄÜ¶¨Ê±Æ÷5       ·¢ËÍ²âÁ¿Âö²«ÃüÁî
} 
if((350<tp_dev.x[t])&&(tp_dev.x[t]<390)&&(270<tp_dev.y[t])&&(tp_dev.y[t]<310))
{
TIM_Cmd(TIM5,DISABLE); //²»Ê¹ÄÜ¶¨Ê±Æ÷5      ¹Ø±Õ²âÁ¿Âö²«ÃüÁî
LCD_Fill(184,270,265,310,WHITE);
LCD_Fill(300,280,330,300,WHITE);
          LCD_DrawRectangle(300,280,330,300);
} 
if((100<tp_dev.x[t])&&(tp_dev.x[t]<160)&&(410<tp_dev.y[t])&&(tp_dev.y[t]<450))
{
Load_Drow_Dialog3();//·¢ËÍ²âÁ¿ÑªÑ¹ÃüÁî
} 
if((350<tp_dev.x[t])&&(tp_dev.x[t]<390)&&(410<tp_dev.y[t])&&(tp_dev.y[t]<450))
{
LCD_Fill(274,480,320,520,WHITE); 
LCD_Fill(274,550,320,590,WHITE); 
LCD_Fill(274,620,320,660,WHITE); 
} 
}
}else lastpos[t][0]=0XFFFF;
}